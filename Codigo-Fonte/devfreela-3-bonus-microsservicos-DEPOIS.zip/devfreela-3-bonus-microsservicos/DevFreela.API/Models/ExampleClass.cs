﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DevFreela.API.Models
{
    public class ExampleClass
    {
        public string Name { get; set; }
    }
}
